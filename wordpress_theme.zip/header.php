<!DOCTYPE html>
<html>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <script src="//unpkg.com/alpinejs" defer></script>
    <link
      rel="stylesheet"
      href=""
    />
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <?php wp_head(); ?>
  </head>
