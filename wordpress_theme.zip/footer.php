</div> <!-- Close content-wrap -->
    <footer class="bg-gray-200 text-white p-4">
        <div class="container flex text-center">
            <p>&copy; <?php echo date('Y'); ?> Brunella's Agency. All rights reserved.</p>
         </div>
    </footer>
</div> <!-- Close page-container -->
<?php wp_footer(); ?>
</body>
